# Contributing #

- Check your code with luacheck before committing
- Create a file called "debug" (no file extension) in the mods root folder to enable verbose logging