

Author : Lanz
Contributors : Danze Fantastic, Ludor Experiens 
Contact : francoisbastidas66@gmail.com
Version : 1.0

You will need BLT to run this mod.
To install the Basic Voices Reborn mods, simply extract each of the sub-menus you want into your Payday 2 mods folder. 

Credits goes to : 

- Danze Fantaztic, for creating the Basic Voices mod. 
I just duplicated his mod to make it bigger and I kept the same name to credit his work. 
His mod can be downloaded here : http://paydaymods.com/mods/144/basicvoices

- Ludor Experiens ; http://steamcommunity.com/profiles/76561198047946878
for his tips on how to make all the menus work all at once. His help was appreciated. 

- me ; http://steamcommunity.com/id/steamlanz
for binding every voice line findable from Lightbulb's Voicelines sheet.
https://docs.google.com/spreadsheets/d/1m0LBg2PKpB-bnWfOFj40AglCI1dLmAHLH3ydi3Y7uz8/edit?pli=1#gid=0


Keep in mind that some of these vocal IDs for Heisters are blank and/or may require specific maps or situations (including stealth and/or loud) to be triggered.
(Example : The Commissar lines only work on Hotline Miami, Russian mercenaries lines work only on Boiling Point)
Also Overkill didnt update all the old lines for every new heister released since the beginning.
So don't expect much from the latest characters. The 4 Payday the Heist heisters were the base for this mod. Dallas to be precise.

Please let me know if you encounter any text issues.

Moderation is the key so avoid spamming to keep it fun.