Introduce:
 This is the strings this mod creats.
 You can use any variables in some strings.
 This README.txt is based on "strings/txt/README.txt"
 If you apply this strings, you need to enable "higher settings".

Variables:
 Some strings are used variables, so you can use it or not.
 This is a list of variables:
    "$heist;"           -> Heist name
    "$day;"             -> The Day you are playing
    "$difficulty;"      -> The difficulty you are playing

 If you want to delete variables or edit, you should edit it as "$var;"

Keys:
 Thid mod creats original keys in strings, so you might be confused when you edit.
 These are explains of keys:
    "cds_idling_upper"          -> Upper text when you are in main menu
    "cds_idling_under"          -> Under text when you are in main menu
    "cds_lobby"                 -> A text when you are in lobby
    "cds_lobby_details"         -> A details text when you are in lobby
    "cds_safehouse"             -> A text when you are in the safe house
    "cds_safehouse_details"     -> A details text when you are in the safe house
    "cds_sp_heist"              -> A text what heist you are playing in single play
    "cds_sp_heist_details"      -> A details text what heist you are playing in single play
    "cds_mp_heist"              -> A text what heist you are playing in multi play
    "cds_mp_heist_details"      -> A details text what heist you are playing in multi play
    "cds_sp_end"                -> A text when you finished heists in single play
    "cds_sp_end_details"        -> A details text when you finished heists in single play
    "cds_mp_end"                -> A text when you finished heists in multi play
    "cds_mp_end_details"        -> A details text when you finished heists in multi play