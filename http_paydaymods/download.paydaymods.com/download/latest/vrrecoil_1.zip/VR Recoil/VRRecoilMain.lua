if not VRRecoil then
	_G.VRRecoil = {}
	VRRecoil.TwohandedRecoilMultiplier = 0.5
end