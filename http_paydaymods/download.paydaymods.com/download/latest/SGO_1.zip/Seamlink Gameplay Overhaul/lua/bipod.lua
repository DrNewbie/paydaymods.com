if not SGO or not SGO.settings.use_lmgs then return end
if SystemFS:exists("mods/Steelsights/mod.txt") then return end
function PlayerBipod:_check_action_steelsight(t, input)
    local new_action
    if self._equipped_unit then
        local result
        local weap_base = self._equipped_unit:base()
        if weap_base.manages_steelsight and weap_base:manages_steelsight() then
            if input.btn_steelsight_press and weap_base.steelsight_pressed then
                result = weap_base:steelsight_pressed()
            elseif input.btn_steelsight_release and weap_base.steelsight_released then
                result = weap_base:steelsight_released()
            end
            if result then
                if result.enter_steelsight and not self._state_data.in_steelsight then
                    self:_start_action_steelsight(t)
                    new_action = true
                elseif result.exit_steelsight and self._state_data.in_steelsight then
                    self:_end_action_steelsight(t)
                    new_action = true
                end
            end
            return new_action
        end
    end
    if managers.user:get_setting("hold_to_steelsight") and input.btn_steelsight_release then
        self._steelsight_wanted = false
        if self._state_data.in_steelsight then
            self:_end_action_steelsight(t)
            new_action = true
        end
    elseif input.btn_steelsight_press or self._steelsight_wanted then
        if self._state_data.in_steelsight then
            self:_end_action_steelsight(t)
            new_action = true
        elseif not self._state_data.in_steelsight then
            self:_start_action_steelsight(t)
            new_action = true
        end
    end
    return new_action
end