if not SGO or not SGO.settings.use_nofa then return end
MenuComponentManager.play_transition = function() end