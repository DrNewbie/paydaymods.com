If you have a low spec machine, just open the LowSpec PC folder
and copy/move sgo.txt back to Seamlink Gameplay Overhaul / menu
THIS WILL REMOVE THE ABILITY TO USE THE WEAPONS OVERHAUL


If you want the default settings back with the overhaul, just 
do the same process but using the file on the Default Settings folder