if CopLogicSniperFocus then
	CopBrain._logic_variants.sniper.sniper = CopLogicSniperFocus
end
