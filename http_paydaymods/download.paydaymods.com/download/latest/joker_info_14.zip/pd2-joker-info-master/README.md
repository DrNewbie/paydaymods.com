# pd2-joker-info
Shows messages about Jokers in chat