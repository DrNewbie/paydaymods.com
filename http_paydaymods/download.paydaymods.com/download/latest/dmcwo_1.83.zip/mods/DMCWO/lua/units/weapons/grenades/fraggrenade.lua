--[[
This script is used in DMC's Weapon Overhaul, please make sure you have the most up to date version
]]

function FragGrenade:bullet_hit()
	--Such code, many line
end