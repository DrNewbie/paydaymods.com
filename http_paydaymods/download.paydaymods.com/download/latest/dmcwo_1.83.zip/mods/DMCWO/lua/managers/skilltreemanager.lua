--[[
This script is used in DMC's Weapon Overhaul, please make sure you have the most up to date version
]]

if DMCWO._data_skills.havel_mum ~= true then
	SkillTreeManager.VERSION = 69
end