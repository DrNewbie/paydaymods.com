Hooks:PostHook(TweakData, "set_hud_values", "convert_all_clean_font", function(self)
	self.hud.medium_font = "fonts/font_large_mf"
	self.hud.medium_font_noshadow = "fonts/font_large_mf"
	self.hud.small_font = "fonts/font_large_mf"
end)