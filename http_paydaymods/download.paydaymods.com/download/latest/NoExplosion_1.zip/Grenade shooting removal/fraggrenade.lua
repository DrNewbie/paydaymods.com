function FragGrenade:bullet_hit()
	--if not Network:is_server() then
		--return
	--end
	--print("FragGrenade:bullet_hit()")
	--self._timer = nil
	--self:_detonate()
end