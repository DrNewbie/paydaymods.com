function IncendiaryGrenade:bullet_hit()
	--if not Network:is_server() then
		--return
	--end
	--self:_detonate()
end