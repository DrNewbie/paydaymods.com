# Jokermon
BLT mod that allows managing and training your Jokers  
**Requires BeardLib and HopLib**