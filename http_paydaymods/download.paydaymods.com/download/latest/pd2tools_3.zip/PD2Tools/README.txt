How to use:

1) Create a loadout on http://pd2tools.com and download the JSON file.
2) Move the JSON file to the mod's "db" folder.
3) While in game, open the inventory page and click on the small saw icon in the rightmost box on the bottom center of the screen.
4) Select the loadout you just created.
5) ???
6) Profit.

Notes:

1) The mod only loads what is in the JSON file, therefore if you created a loadout with no skills the mod will leave your current equipped skill set untouched.
2) Make sure you have empty weapon slots if you want the mod to craft the loadout weapons.
3) If you wish to rename your loadout, choose a name shorter than 15 characters. This is the maximum length accepted by the game UI for skill sets.
4) Do not rename your weapons if you plan to reuse them with a loadout. The mod checks for weapon names before crafting new weapons.
5) You can keep as many loadouts as want, just import them whenever you need it.