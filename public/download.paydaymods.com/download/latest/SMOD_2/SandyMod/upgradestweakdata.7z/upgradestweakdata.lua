local old_init = UpgradesTweakData.init

function UpgradesTweakData:init(tweak_data)
        old_init(self, tweak_data)
		

	--Yakuza
	self.values.player.movement_speed_damage_health_ratio_threshold_multiplier = {4} --1
	
	--Frenzy
	self.values.player.healing_reduction = {0.25, 0.5} --{0.25, 1}
	self.values.player.health_damage_reduction = {0.75, 0.55} --{0.9, 0.75}
	self.values.player.max_health_reduction = {0.05} --{0.3}
	
	--Grenade case
	self.grenade_crate_base = 15 --3
	
	--Inspire
	self.values.cooldown.long_dis_revive = {
		{0.75, 0} --{1, 20}
	}
	--Inspire non-revive stuff
	self.morale_boost_time = 30
	
	--Fully Loaded and Walk in closet
	self.values.player.pick_up_ammo_multiplier = {1.35, 2.15} --{1.35, 1.75}
	
	--Movement penalty
	--self.weapon_movement_penalty.minigun = 0.6
	
	--Grinder
	self.damage_to_hot_data = {
		armors_allowed = {"level_1", "level_2", "level_5"}, --{"level_1", "level_2"},
		works_with_armor_kit = true,
		tick_time = 0.25, --0.5
		total_ticks = 3, --6,
		max_stacks = false,
		stacking_cooldown = 1.5,
		add_stack_sources = {
			bullet = true,
			explosion = true,
			melee = true,
			taser_tased = true,
			poison = true,
			fire = true,
			swat_van = true,
			civilian = false
		}
	}
	self.values.player.damage_to_hot = {
		0.15,
		0.25,
		0.35,
		0.45
	}
	self.values.player.damage_to_hot_extra_ticks = {2}
	
	--Anarchist
	self.values.player.armor_increase = {
		1,
		1.1,
		1.8
	}

	
	--Armors
	self.values.player.body_armor = {}
	self.values.player.body_armor.armor = {
		0,
		3,
		4,
		5,
		9, --7,
		13, --9,
		15
	}
	self.values.player.body_armor.movement = {
		1.05,
		1.025,
		1,
		0.95,
		0.95,
		0.65,
		0.575
	}
	self.values.player.body_armor.concealment = {
		30,
		26,
		23,
		21,
		18,
		12,
		1
	}
	self.values.player.body_armor.dodge = {
		0.05,
		-0.05,
		-0.1,
		-0.15,
		-0.1,
		-0.25,
		-0.55
	}
	self.values.player.body_armor.damage_shake = {
		1,
		0.96,
		0.92,
		0.85,
		0.8,
		0.7,
		0.5
	}
	self.values.player.body_armor.stamina = {
		1.025,
		1,
		0.95,
		0.9,
		1,
		0.8,
		0.7
	}

end