# Third Person
This is an experimental mod that enables third person mode. It has adjustable camera settings and keybinds to change some options on the fly.

## WARNING
This is might not play well with character, weapon or other related mods and could crash your game.

## Known issues
- Animations are incorrect on ziplines and during jumping
- Aiming in third person is difficult since the aim point is not the screen center
- Activating bipods does not work in third person
