tweak_data.projectiles.molotov.player_damage = 1.5
tweak_data.projectiles.molotov.fire_dot_data = {
	dot_damage = 1,
			dot_trigger_max_distance = 3000,
			dot_trigger_chance = 35,
			dot_length = 2,
			dot_tick_period = 0.5
		}
	tweak_data.projectiles.molotov.burn_duration = 15
	
tweak_data.projectiles.launcher_incendiary.player_damage = 1.5
tweak_data.projectiles.launcher_incendiary.fire_dot_data = {
			dot_damage = 1,
			dot_trigger_max_distance = 3000,
			dot_trigger_chance = 35,
			dot_length = 2,
			dot_tick_period = 0.5
		}