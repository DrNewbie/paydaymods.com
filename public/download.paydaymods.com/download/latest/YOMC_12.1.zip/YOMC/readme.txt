**FIRST OF ALL**
Credit where it is due. DMCWO is definitely a very strong inspiration and reference for this project, but at the same time after weeks of messing with
things I've more or less made it my own. 

The base of this was initially a modified lite version of DMC, heavily rewritten and with old features removed, whilst also introducing new ones.
Basically just enough to do a proper rebalance, and not an overhaul. 

So credit to all the guys at DMCWO, DMC, who has graciously given me permission to reuse some of his code entirely, LazyOzzy, who originally coded so much of this work that
honestly most of the features would have to be credited to him, B1313 and co. We might not see eye to eye on some things regarding cheating but I recognise the talent it takes to do what they do.

---------------------------------------------------------------------------------------
**INSTALLATION**
You will need BLT for this mod to function, it can be found here: 
http://paydaymods.com/download/

Once that is installed, put this entire folder into the folder called "mods" in your Payday 2 game directory. If this doesn't exist then create it.
---------------------------------------------------------------------------------------
**CHANGELOG**
Look in the steamgroup

---------------------------------------------------------------------------------------