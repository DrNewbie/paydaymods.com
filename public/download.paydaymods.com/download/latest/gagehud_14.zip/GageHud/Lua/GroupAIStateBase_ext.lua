local init_original = GroupAIStateBase.init
local update_original = GroupAIStateBase.update
local register_turret_original = GroupAIStateBase.register_turret
local unregister_turret_original = GroupAIStateBase.unregister_turret
local set_whisper_mode_original = GroupAIStateBase.set_whisper_mode
local convert_hostage_to_criminal_original = GroupAIStateBase.convert_hostage_to_criminal
local sync_converted_enemy_original = GroupAIStateBase.sync_converted_enemy
local on_hostage_state_original = GroupAIStateBase.on_hostage_state
local sync_hostage_headcount_original = GroupAIStateBase.sync_hostage_headcount

function GroupAIStateBase:init(...)
	self._civilian_hostages = 0
	return init_original(self, ...)
end

function GroupAIStateBase:update(t, ...)
	if self._client_hostage_count_expire_t and t < self._client_hostage_count_expire_t then
		self:_client_hostage_count_cbk()
	end
	
	return update_original(self, t, ...)
end

function GroupAIStateBase:register_turret(unit, ...)
	managers.enemy:_change_swat_turret_count(1)
	return register_turret_original(self, unit, ...)
end

function GroupAIStateBase:unregister_turret(unit, ...)
	managers.enemy:_change_swat_turret_count(-1)
	return unregister_turret_original(self, unit, ...)
end

function GroupAIStateBase:set_whisper_mode(enabled, ...)
	if not enabled then
		managers.interaction:remove_all_pagers()
	end
	return set_whisper_mode_original(self, enabled, ...)
end

function GroupAIStateBase:convert_hostage_to_criminal(unit, peer_unit, ...)
	convert_hostage_to_criminal_original(self, unit, peer_unit, ...)
	
	if unit:brain()._logic_data.is_converted then
		local peer_id = peer_unit and managers.network:game():member_from_unit(peer_unit):peer():id() or managers.network:session():local_peer():id()
		local owner_base = peer_unit and peer_unit:base() or managers.player
		local upgrade = (owner_base:upgrade_level("player", "convert_enemies_health_multiplier") or 0) > 0
		managers.enemy:add_minion_unit(unit, peer_id, upgrade)
	end
end

function GroupAIStateBase:sync_converted_enemy(converted_enemy, ...)
	sync_converted_enemy_original(self, converted_enemy, ...)
	managers.enemy:add_minion_unit(converted_enemy)
end

function GroupAIStateBase:on_hostage_state(...)
	on_hostage_state_original(self, ...)
	self:_update_hostage_count()
end

function GroupAIStateBase:sync_hostage_headcount(...)
	sync_hostage_headcount_original(self, ...)
	
	if Network:is_server() then
		self:_update_hostage_count()
	else
		self._client_hostage_count_expire_t = self._t + 10
	end
end


function GroupAIStateBase:hostage_count_by_type(u_type)
	if u_type == "cop_hostage" then
		return self:police_hostage_count()	--Default function, updated for client-side
	elseif u_type == "civilian_hostage" then
		return self:civilian_hostage_count()	--Custom function
	elseif u_type == nil then
		return  self:hostage_count()	--Default function, total hostages
	end
end

function GroupAIStateBase:civilian_hostage_count()
	return self._civilian_hostages
end

function GroupAIStateBase:_client_hostage_count_cbk()
	local police_count = 0
	for u_key, u_data in pairs(managers.enemy:all_enemies()) do
		if u_data and u_data.unit and u_data.unit.anim_data and u_data.unit:anim_data() then
			if u_data.unit:anim_data().surrender then
				police_count = police_count + 1
			end
		end
	end
	
	self._police_hostage_headcount = police_count
	self._civilian_hostages = self:hostage_count() - self._police_hostage_headcount
	self:_update_hostage_count()
end

function GroupAIStateBase:_update_hostage_count()
	if Network:is_server() then
		self._civilian_hostages = self._hostage_headcount - self._police_hostage_headcount
	end
	
	if managers.hud and managers.hud:list_initialized() then
		if HUDManager.ListOptions.show_civilians then
			managers.hud:hud_list("right_side_list"):item("enemy_count_list"):item("civilian"):set_count(managers.enemy:unit_count("civilian") - self:civilian_hostage_count())
		end
		
		if HUDManager.ListOptions.show_hostages then
			managers.hud:hud_list("right_side_list"):item("hostage_count_list"):item("civilian_hostage"):set_count(self:civilian_hostage_count())
			managers.hud:hud_list("right_side_list"):item("hostage_count_list"):item("cop_hostage"):set_count(self:police_hostage_count())
		end
	end
end
if mod_collection and mod_collection._data.enable_pacified then
	local _upd_criminal_suspicion_progress_original = GroupAIStateBase._upd_criminal_suspicion_progress
	function GroupAIStateBase:_upd_criminal_suspicion_progress(...)
		if self._ai_enabled then
			for obs_key, obs_susp_data in pairs(self._suspicion_hud_data or {}) do
				local unit = obs_susp_data.u_observer
				
				if managers.enemy:is_civilian(unit) then
					local waypoint = managers.hud._hud.waypoints["susp1" .. tostring(obs_key)]
					
					if waypoint then
						local color, arrow_color
						
						if unit:anim_data().drop then
							if not obs_susp_data._subdued_civ then
								obs_susp_data._alerted_civ = nil
								obs_susp_data._subdued_civ = true
								color = Color(0, 0.71, 1)
								arrow_color = Color(0, 0.35, 0.5)
								waypoint.bitmap:set_texture_rect(2, 644, 128, 128, color)
								--waypoint.bitmap:set_w(30)
								--waypoint.bitmap:set_h(40)
								--waypoint.bitmap:set_texture_rect(882, 432, 60, 80, color)
							end
						elseif obs_susp_data.alerted then
							if not obs_susp_data._alerted_civ then
								obs_susp_data._subdued_civ = nil
								obs_susp_data._alerted_civ = true
								color = Color.white
								arrow_color = tweak_data.hud.detected_color
								--waypoint.bitmap:set_image("guis/textures/hud_icons")
								waypoint.bitmap:set_texture_rect(479, 433, 32, 32, color)
							end
						end
						
						if color then
							waypoint.bitmap:set_color(color)
							waypoint.arrow:set_color(arrow_color:with_alpha(0.75))
						end
					end
				end
			end
		end
		
		return _upd_criminal_suspicion_progress_original(self, ...)
	end
end
