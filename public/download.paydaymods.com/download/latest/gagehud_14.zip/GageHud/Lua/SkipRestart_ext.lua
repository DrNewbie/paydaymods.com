if not SkipRestart then
	if tweak_data then
		tweak_data.voting.restart_delay = 0
	end
end