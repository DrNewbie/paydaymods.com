----Installation----
BLT is required, if you haven't got it, you can download it here: https://paydaymods.com/download/

Extract the zip files.

Just drag and drop the folder in your payday 2 directory in the "mods" folder (steamapps\common\PAYDAY 2\mods\)

----Presentation videos----
https://www.youtube.com/watch?v=B6qBIJDURzo

----Menu----
You can set you're settings in the ingame menu: Options/mods options/Jacket's Minimap
actually the zoom/scale feature don't work, it will be fixed as soon as possible.

From the menu you can:
 - enable/disable the minimap
 - enable/disable the rotation of the minimap
 - enable/disable the auto-hide of the minimap if alarm is raised
 - set zoom (not working)

if u're in offline mod, you have to set the setting you want and disable minimap, leave menu and go back in game, then go back to menu and re enable minimap to make the minimap apply the settings you modified.

----Credit----
Most of the credit goes to LazyOzzy for create the original minimap: http://www.unknowncheats.me/forum/payday-2-a/136630-game-map.html

----Vylaxez----
You can acces my website at vylaxez-payday2.livehost.fr (If I finished it) for my mods and vylaxez.livehost.fr for others